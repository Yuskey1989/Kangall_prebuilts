    write /sys/block/zram0/max_comp_streams 4
    write /sys/block/zram0/comp_algorithm "lz4"
    write /sys/block/zram0/disksize  "256M"
    swapon_all ./fstab.hammerhead
